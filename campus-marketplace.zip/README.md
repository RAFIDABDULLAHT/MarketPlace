# 🎓 CampusMarket — Student-to-Student Campus Marketplace

A student-to-student marketplace for buying and selling used books, cycles, electronics, and hostel essentials on campus. Built with React, Vite, Tailwind CSS, and Firebase Firestore.

---

## 🚀 Features

- **Checked-Notebook Design**: Retro campus notepad aesthetic with high contrast typography and responsive grid layout.
- **Real-Time Firestore Database**: Synchronized listing stream via `onSnapshot` ordered by creation date descending.
- **Client-Side Image Compression**: Instant Base64 photo compression keeping payloads under Firestore limits with zero external storage requirements.
- **Smart AI Item Description Helper**: Fast local and Gemini API fallback for generating item descriptions.
- **Instant Item Sharing**: Paper-plane Share button supporting native `navigator.share` on mobile devices and clipboard copy toast notification on desktop.
- **Open Graph Social Previews**: Rich unfurling meta tags for WhatsApp, Instagram DMs, and Twitter.

---

## 🛠️ Environment Variables Configuration

Copy `.env.example` to `.env.local` and configure your Firebase keys:

```env
VITE_FIREBASE_API_KEY="your-api-key"
VITE_FIREBASE_AUTH_DOMAIN="marketplace-c6226.firebaseapp.com"
VITE_FIREBASE_PROJECT_ID="marketplace-c6226"
VITE_FIREBASE_STORAGE_BUCKET="marketplace-c6226.firebasestorage.app"
VITE_FIREBASE_MESSAGING_SENDER_ID="257671278705"
VITE_FIREBASE_APP_ID="1:257671278705:web:312e0ad6b7b88b4e48abd0"
VITE_FIREBASE_MEASUREMENT_ID="G-KQ7RPZXJQE"
```

---

## 📦 Deploying to Vercel

Follow these simple steps to deploy **CampusMarket** on Vercel:

### Option 1: Via Vercel Web Dashboard (Recommended)

1. Push your repository to **GitHub** or **GitLab**.
2. Go to [Vercel Dashboard](https://vercel.com/new) and click **Import Project**.
3. Select your repository.
4. Set Framework Preset: **Vite**.
5. Build Command: `npm run build`
6. Output Directory: `dist`
7. Under **Environment Variables**, add the environment variables listed in `.env.example`:
   - `VITE_FIREBASE_API_KEY`
   - `VITE_FIREBASE_AUTH_DOMAIN`
   - `VITE_FIREBASE_PROJECT_ID`
   - `VITE_FIREBASE_STORAGE_BUCKET`
   - `VITE_FIREBASE_MESSAGING_SENDER_ID`
   - `VITE_FIREBASE_APP_ID`
8. Click **Deploy**. Vercel will build and host your app live in under a minute!

### Option 2: Via Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Log in to your Vercel account
vercel login

# Deploy project
vercel --prod
```

---

## 🧪 Local Development

```bash
# Install dependencies
npm install

# Start local Vite development server
npm run dev

# Run TypeScript linting checks
npm run lint

# Create production build
npm run build
```
