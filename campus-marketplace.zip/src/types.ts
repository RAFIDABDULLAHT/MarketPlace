export type Category = 'Books' | 'Cycles' | 'Electronics' | 'Other';

export type Condition = 'Like New' | 'Good' | 'Fair';

export interface Listing {
  id: string;
  title: string;
  category: Category;
  price: number;
  condition: Condition;
  description: string;
  imageUrl: string;
  imageBase64?: string;
  sellerId?: string;
  sellerName: string;
  sellerHostel: string;
  sellerPhone: string;
  createdAt: string;
  isNew?: boolean;
  isUploading?: boolean;
}
