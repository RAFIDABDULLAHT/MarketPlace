import React from 'react';
import { Pencil, Heart, GraduationCap } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#FAFBFC] text-[#1B3A5C] py-12 border-t-2 border-[#C9E2F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 pb-8 border-b-2 border-[#C9E2F5]">
          {/* Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-[#FFD93D] border-2 border-[#1B3A5C] text-[#1B3A5C] flex items-center justify-center font-bold">
              <Pencil className="w-5 h-5 text-[#1B3A5C]" />
            </div>
            <div>
              <span className="font-extrabold text-[#1B3A5C] text-lg tracking-tight">CampusMarket</span>
              <p className="text-xs text-[#1B3A5C]/70 font-bold">Student-to-Student Used Items Exchange</p>
            </div>
          </div>

          {/* Quick Info Badges */}
          <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-bold text-[#1B3A5C]">
            <span className="flex items-center gap-1 bg-[#FFD93D] px-3.5 py-1.5 rounded-full border-2 border-[#1B3A5C]">
              <GraduationCap className="w-4 h-4 text-[#1B3A5C]" /> Peer-to-Peer Verified
            </span>
            <span className="bg-[#FAFBFC] px-3.5 py-1.5 rounded-full border-2 border-[#1B3A5C]">
              📍 Safe Meeting Points: Library Quad & Food Court
            </span>
          </div>
        </div>

        {/* Required Footer Text */}
        <div className="pt-8 text-center flex flex-col items-center justify-center gap-2">
          <p className="text-sm font-black text-[#E63946] tracking-wide flex items-center gap-1.5">
            <span>Built live at the VinnovateIT Vibe Coding Workshop</span>
            <Heart className="w-4 h-4 text-[#E63946] fill-[#E63946] inline" />
          </p>
          <p className="text-xs text-[#1B3A5C] font-bold">
            © {new Date().getFullYear()} AI Campus Marketplace. Designed for students, by students.
          </p>
        </div>
      </div>
    </footer>
  );
};
