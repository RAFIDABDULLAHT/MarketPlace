import React from 'react';
import { ArrowDown, BookOpen, Bike, Laptop, Sparkles, MapPin, CheckCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroSectionProps {
  onBrowseClick: () => void;
  onSellClick: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onBrowseClick, onSellClick }) => {
  return (
    <section className="relative pt-12 pb-16 md:pt-20 md:pb-24 overflow-hidden border-b-2 border-[#C9E2F5] graph-paper-bg">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 relative text-center">
        
        {/* Scattered Sticky Note Labels around Hero */}
        <motion.div 
          initial={{ opacity: 0, rotate: -12, y: -10 }}
          animate={{ opacity: 1, rotate: -6, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="absolute left-2 sm:left-6 top-2 sm:top-6 bg-[#FFD93D] text-[#1B3A5C] px-3.5 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm border-2 border-[#1B3A5C] shadow-md hidden xs:flex items-center gap-1 -rotate-6 select-none"
        >
          <CheckCircle className="w-3.5 h-3.5 text-[#1B3A5C]" />
          <span>2nd-hand ✓</span>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, rotate: 12, y: -10 }}
          animate={{ opacity: 1, rotate: 5, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="absolute right-2 sm:right-8 top-4 sm:top-8 bg-[#FFD93D] text-[#1B3A5C] px-3.5 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm border-2 border-[#1B3A5C] shadow-md hidden xs:flex items-center gap-1 rotate-6 select-none"
        >
          <span>No fees 🏷️</span>
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, rotate: -8, y: 10 }}
          animate={{ opacity: 1, rotate: -3, y: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="absolute right-6 sm:right-16 bottom-2 bg-[#FFD93D] text-[#1B3A5C] px-3.5 py-1.5 rounded-xl font-extrabold text-xs sm:text-sm border-2 border-[#1B3A5C] shadow-md hidden md:flex items-center gap-1 -rotate-3 select-none z-10"
        >
          <span>Same day pickup ⚡</span>
        </motion.div>

        {/* Top Campus Badge */}
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-[#FAFBFC] text-[#1B3A5C] text-xs font-black border-2 border-[#1B3A5C] shadow-xs mb-6"
        >
          <span className="w-2.5 h-2.5 rounded-full bg-[#E63946] animate-pulse" />
          <span className="text-[#E63946] font-black uppercase tracking-wider">Campus Verified</span>
          <span className="text-[#1B3A5C]/40">•</span>
          <span className="text-[#1B3A5C] flex items-center gap-1 font-bold">
            <MapPin className="w-3.5 h-3.5 text-[#E63946]" /> Hostels & Quads
          </span>
        </motion.div>

        {/* Hero Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl sm:text-5xl md:text-6xl font-black text-[#1B3A5C] tracking-tight leading-[1.15] mb-6 uppercase"
        >
          Sell it. Find it. <br className="hidden sm:inline" />
          <span className="relative inline-block text-[#1B3A5C]">
            Campus only.
            <svg
              className="absolute -bottom-2 left-0 w-full h-3.5 text-[#E63946] pointer-events-none"
              viewBox="0 0 200 12"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                d="M3 8.5C50 3.5 130 2.5 197 9.5"
                stroke="currentColor"
                strokeWidth="5"
                strokeLinecap="round"
              />
            </svg>
          </span>
        </motion.h1>

        {/* One-line Subheading */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="text-base sm:text-lg md:text-xl text-[#1B3A5C] max-w-2xl mx-auto font-bold leading-relaxed mb-8"
        >
          The peer-to-peer student marketplace for textbooks, cycles, and electronics at honest campus prices.
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-4 max-w-md mx-auto"
        >
          <button
            onClick={onBrowseClick}
            id="hero-browse-cta"
            className="w-full sm:w-auto flex items-center justify-center gap-2 text-base font-extrabold text-white bg-[#E63946] hover:bg-[#D62839] px-8 py-3.5 rounded-full shadow-md hover:-translate-y-0.5 transition-all active:scale-95 group cursor-pointer border-2 border-[#1B3A5C]"
          >
            <span>Browse listings</span>
            <ArrowDown className="w-5 h-5 text-white group-hover:translate-y-1 transition-transform" />
          </button>

          <button
            onClick={onSellClick}
            className="w-full sm:w-auto flex items-center justify-center gap-2 text-base font-extrabold text-[#1B3A5C] bg-[#FFD93D] hover:bg-amber-300 border-2 border-[#1B3A5C] px-8 py-3.5 rounded-full shadow-xs hover:-translate-y-0.5 transition-all active:scale-95 cursor-pointer"
          >
            <Sparkles className="w-5 h-5 text-[#1B3A5C]" />
            <span>Sell an Item</span>
          </button>
        </motion.div>

        {/* Category Feature Highlights */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="mt-12 pt-8 border-t-2 border-[#C9E2F5] grid grid-cols-3 gap-3 sm:gap-5 max-w-xl mx-auto"
        >
          <div className="flex flex-col items-center p-3.5 rounded-2xl bg-[#FAFBFC] border-2 border-[#1B3A5C] shadow-2xs">
            <BookOpen className="w-6 h-6 text-[#E63946] mb-1" />
            <span className="text-xs font-black text-[#1B3A5C]">Books & Notes</span>
          </div>
          <div className="flex flex-col items-center p-3.5 rounded-2xl bg-[#FAFBFC] border-2 border-[#1B3A5C] shadow-2xs">
            <Bike className="w-6 h-6 text-[#E63946] mb-1" />
            <span className="text-xs font-black text-[#1B3A5C]">Bicycles & Gear</span>
          </div>
          <div className="flex flex-col items-center p-3.5 rounded-2xl bg-[#FAFBFC] border-2 border-[#1B3A5C] shadow-2xs">
            <Laptop className="w-6 h-6 text-[#E63946] mb-1" />
            <span className="text-xs font-black text-[#1B3A5C]">Gadgets & Tech</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
