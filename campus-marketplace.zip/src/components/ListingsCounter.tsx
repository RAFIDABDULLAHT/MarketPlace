import React, { useEffect, useState } from 'react';
import { ShoppingBag, TrendingUp } from 'lucide-react';

interface ListingsCounterProps {
  targetCount: number;
}

export const ListingsCounter: React.FC<ListingsCounterProps> = ({ targetCount }) => {
  const [currentCount, setCurrentCount] = useState<number>(0);

  useEffect(() => {
    // If current count is less than target, count up one at a time
    if (currentCount < targetCount) {
      const timer = setTimeout(() => {
        setCurrentCount((prev) => prev + 1);
      }, 180); // Speed: ~180ms per tick for smooth visible increment
      return () => clearTimeout(timer);
    } else if (currentCount > targetCount) {
      // If items removed, update
      setCurrentCount(targetCount);
    }
  }, [currentCount, targetCount]);

  return (
    <div className="inline-flex items-center gap-2.5 px-4 py-2 bg-[#FFD93D] border-2 border-[#1B3A5C] text-[#1B3A5C] rounded-full shadow-xs">
      <span className="relative flex h-2.5 w-2.5">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#E63946] opacity-75"></span>
        <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#E63946]"></span>
      </span>
      <ShoppingBag className="w-4 h-4 text-[#1B3A5C]" />
      <div className="text-sm font-black flex items-center gap-1.5">
        <span className="text-xs uppercase tracking-wider text-[#1B3A5C]">Active Campus Listings:</span>
        <span className="font-mono text-base font-black text-white bg-[#E63946] px-2.5 py-0.5 rounded-full min-w-[30px] text-center transition-all duration-300 shadow-2xs border border-[#1B3A5C]">
          {currentCount}
        </span>
      </div>
      {targetCount > 0 && (
        <span className="hidden sm:inline-flex items-center text-xs font-black text-[#1B3A5C] bg-[#FAFBFC] px-2.5 py-0.5 rounded-full border border-[#1B3A5C]">
          <TrendingUp className="w-3 h-3 mr-1 text-[#E63946]" /> Verified Live
        </span>
      )}
    </div>
  );
};
