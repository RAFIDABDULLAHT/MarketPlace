import React, { useState, useRef } from 'react';
import { Category, Condition, Listing } from '../types';
import { CATEGORY_PRESET_IMAGES } from '../data/mockListings';
import { createListingInFirestore, compressImageFileToBase64, urlToBase64 } from '../lib/firebase';
import { Tag, IndianRupee, Sparkles, CheckCircle2, Image as ImageIcon, User, Building, AlertCircle, Upload, Send, FileImage } from 'lucide-react';
import confetti from 'canvas-confetti';

interface SellFormProps {
  onAddListing?: (newListing: Listing) => void;
}

export const SellForm: React.FC<SellFormProps> = ({ onAddListing }) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Category>('Books');
  const [price, setPrice] = useState<string>('');
  const [condition, setCondition] = useState<Condition>('Good');
  const [description, setDescription] = useState('');
  const [sellerName, setSellerName] = useState('Rahul Sharma');
  const [sellerHostel, setSellerHostel] = useState('MH-3 Hostel, Room 210');
  const [sellerPhone, setSellerPhone] = useState('+91 98765 12345');
  const [customImage, setCustomImage] = useState('');
  const [imageBase64, setImageBase64] = useState<string>('');
  const [imageFileName, setImageFileName] = useState<string>('');
  const [isProcessingImage, setIsProcessingImage] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccessToast, setShowSuccessToast] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const categories: Category[] = ['Books', 'Cycles', 'Electronics', 'Other'];
  const conditions: Condition[] = ['Like New', 'Good', 'Fair'];

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setErrorMessage('Please select a valid image file (JPG, PNG, WEBP).');
      return;
    }

    try {
      setErrorMessage('');
      setIsProcessingImage(true);
      setImageFileName(file.name);
      
      // Compress file to base64 client-side
      const compressed = await compressImageFileToBase64(file, 600, 600, 0.7);
      setImageBase64(compressed);
      setCustomImage(''); // Clear URL if file uploaded
    } catch (err) {
      console.error('Image compression error:', err);
      setErrorMessage('Failed to process photo. Please try another image.');
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleAiEnhance = async () => {
    if (!title) {
      setErrorMessage('Please type an Item Name first to use AI description generator!');
      return;
    }
    setErrorMessage('');
    setIsGeneratingAi(true);

    try {
      const res = await fetch('/api/generate-description', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, category, condition }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.description) {
          setDescription(data.description);
          if (data.suggestedPrice && !price) {
            setPrice(String(data.suggestedPrice));
          }
        }
      } else {
        generateLocalAiDescription();
      }
    } catch {
      generateLocalAiDescription();
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const generateLocalAiDescription = () => {
    const templates: Record<Category, string> = {
      Books: `Well-maintained copy of ${title}. Clean pages, no torn corners. Great for exams and semester reference!`,
      Cycles: `Super smooth ride! ${title} in ${condition.toLowerCase()} condition. Brakes and tires in solid shape. Comes with lock.`,
      Electronics: `${title} working 100% perfectly. Used carefully during lab sessions. Clean condition, includes cable.`,
      Other: `${title} in ${condition.toLowerCase()} shape. Great deal for campus students!`,
    };
    setDescription(templates[category]);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMessage('Please enter an item name.');
      return;
    }
    const parsedPrice = parseFloat(price);
    if (isNaN(parsedPrice) || parsedPrice <= 0) {
      setErrorMessage('Please enter a valid price in rupees (₹).');
      return;
    }
    if (!description.trim()) {
      setErrorMessage('Please add a short description.');
      return;
    }

    setErrorMessage('');
    setIsSubmitting(true);

    try {
      let finalBase64 = imageBase64;

      // If user typed custom URL and no file was picked
      if (!finalBase64 && customImage.trim()) {
        finalBase64 = await urlToBase64(customImage.trim());
        if (!finalBase64) {
          finalBase64 = customImage.trim(); // fallback string
        }
      }

      // Write directly to Firestore
      await createListingInFirestore({
        name: title.trim(),
        category,
        price: Math.round(parsedPrice),
        condition,
        description: description.trim(),
        imageBase64: finalBase64,
        sellerName: sellerName.trim() || 'Campus Student',
        sellerHostel: sellerHostel.trim() || 'MH-1 Hostel',
        sellerPhone: sellerPhone.trim() || '+91 99999 88888',
      });

      // Trigger confetti celebration
      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#E63946', '#FFD93D', '#1B3A5C'],
        });
      } catch (err) {
        console.log('Confetti effect:', err);
      }

      // Reset form
      setTitle('');
      setPrice('');
      setDescription('');
      setCustomImage('');
      setImageBase64('');
      setImageFileName('');
      setShowSuccessToast(true);

      setTimeout(() => {
        setShowSuccessToast(false);
      }, 4000);
    } catch (err) {
      console.error('Error creating Firestore listing:', err);
      setErrorMessage('Failed to publish listing to database. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="sell-form-section" className="py-12 md:py-16 graph-paper-bg relative">
      <div className="max-w-3xl mx-auto px-4 sm:px-6">
        {/* Form Card: Coupon Cut-out Style */}
        <div className="bg-[#FAFBFC] border-2 border-dashed border-[#1B3A5C]/40 rounded-2xl p-6 sm:p-10 shadow-lg relative overflow-hidden">
          {/* Top Paper-Clip / Coupon Header */}
          <div className="flex items-center justify-between border-b-2 border-[#C9E2F5] pb-5 mb-8">
            <div className="flex items-center gap-3.5">
              <div className="w-10 h-10 rounded-2xl bg-[#FFD93D] border-2 border-[#1B3A5C] text-[#1B3A5C] flex items-center justify-center font-black text-base shadow-2xs">
                2
              </div>
              <div>
                <h2 className="text-xl sm:text-2xl font-black text-[#1B3A5C] tracking-tight">
                  Sell an item
                </h2>
                <p className="text-xs text-[#1B3A5C]/80 font-bold">Post your item for free to verified hostel mates</p>
              </div>
            </div>
            <span className="text-xs font-black px-3 py-1 bg-[#FFD93D] text-[#1B3A5C] rounded-full border-2 border-[#1B3A5C] hidden sm:inline-block">
              Free Campus Coupon
            </span>
          </div>

          {errorMessage && (
            <div className="mb-6 p-4 bg-red-50 border-2 border-[#E63946] rounded-2xl flex items-center gap-2.5 text-sm text-[#E63946] font-extrabold">
              <AlertCircle className="w-5 h-5 text-[#E63946] shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {showSuccessToast && (
            <div className="mb-6 p-4 bg-emerald-50 border-2 border-emerald-500 rounded-2xl flex items-center gap-3 text-sm text-emerald-900 font-extrabold shadow-xs animate-bounce">
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              <span>Item posted successfully! Scrolling down to your live card in the grid...</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Field 1: Item Name */}
            <div>
              <label className="block text-sm font-extrabold text-[#1B3A5C] mb-2">
                Item Name <span className="text-[#E63946]">*</span>
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Data Structures Book, Hero Octane Bike, Casio Calculator"
                className="w-full px-4 py-3.5 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-[#1B3A5C] text-sm font-bold focus:outline-none focus:border-[#E63946] focus:ring-2 focus:ring-[#E63946]/20 transition-all placeholder:text-[#1B3A5C]/40"
              />
            </div>

            {/* Field 2 & 3: Category & Price */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {/* Category selector: Tappable pill chips */}
              <div>
                <label className="block text-sm font-extrabold text-[#1B3A5C] mb-2">
                  Category <span className="text-[#E63946]">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2.5">
                  {categories.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setCategory(cat)}
                      className={`px-3 py-2.5 rounded-full text-xs font-black transition-all border-2 text-center cursor-pointer ${
                        category === cat
                          ? 'bg-[#E63946] border-[#E63946] text-white shadow-xs scale-105'
                          : 'bg-[#FAFBFC] text-[#1B3A5C] border-[#1B3A5C] hover:bg-[#C9E2F5]/30'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
              </div>

              {/* Price in Rupees */}
              <div>
                <label className="block text-sm font-extrabold text-[#1B3A5C] mb-2">
                  Price in Rupees (₹) <span className="text-[#E63946]">*</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-[#1B3A5C]">
                    <IndianRupee className="w-4 h-4 text-[#1B3A5C]" />
                  </div>
                  <input
                    type="number"
                    min="1"
                    required
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    placeholder="e.g. 450"
                    className="w-full pl-9 pr-4 py-3.5 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-[#1B3A5C] font-black text-sm focus:outline-none focus:border-[#E63946] focus:ring-2 focus:ring-[#E63946]/20 transition-all placeholder:text-[#1B3A5C]/40"
                  />
                </div>
                <p className="text-[11px] text-[#1B3A5C]/70 font-bold mt-1">Honest price for hostel students</p>
              </div>
            </div>

            {/* Field 4: Condition Tappable pill chips */}
            <div>
              <label className="block text-sm font-extrabold text-[#1B3A5C] mb-2">
                Condition <span className="text-[#E63946]">*</span>
              </label>
              <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
                {conditions.map((cond) => (
                  <button
                    key={cond}
                    type="button"
                    onClick={() => setCondition(cond)}
                    className={`px-3 py-2.5 rounded-full text-xs sm:text-sm font-black transition-all border-2 text-center cursor-pointer ${
                      condition === cond
                        ? 'bg-[#E63946] border-[#E63946] text-white shadow-xs scale-105'
                        : 'bg-[#FAFBFC] text-[#1B3A5C] border-[#1B3A5C] hover:bg-[#C9E2F5]/30'
                    }`}
                  >
                    {cond}
                  </button>
                ))}
              </div>
            </div>

            {/* Field 5: Short Description */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="block text-sm font-extrabold text-[#1B3A5C]">
                  Short Description <span className="text-[#E63946]">*</span>
                </label>
                <button
                  type="button"
                  onClick={handleAiEnhance}
                  disabled={isGeneratingAi}
                  className="inline-flex items-center gap-1.5 text-xs font-black text-[#1B3A5C] bg-[#FFD93D] hover:bg-amber-300 px-3 py-1 rounded-full border border-[#1B3A5C] transition-colors cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 text-[#1B3A5C]" />
                  <span>{isGeneratingAi ? 'Writing...' : 'AI Polish'}</span>
                </button>
              </div>
              <textarea
                required
                rows={3}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Mention details like edition, usage, condition specs, accessories included, or hostel pickup location..."
                className="w-full px-4 py-3.5 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-[#1B3A5C] text-sm font-bold focus:outline-none focus:border-[#E63946] focus:ring-2 focus:ring-[#E63946]/20 transition-all placeholder:text-[#1B3A5C]/40"
              />
            </div>

            {/* Photo Selection: File Upload with Base64 Compression or Custom URL */}
            <div>
              <label className="block text-sm font-extrabold text-[#1B3A5C] mb-2">
                Item Photo (Upload file or paste URL)
              </label>

              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileChange}
                accept="image/*"
                className="hidden"
              />

              <div className="space-y-3">
                {/* File Upload Button / Selected Status */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isProcessingImage}
                    className="px-4 py-3 bg-[#FFD93D] hover:bg-amber-300 text-[#1B3A5C] font-black text-xs rounded-2xl border-2 border-[#1B3A5C] flex items-center justify-center gap-2 transition-all cursor-pointer shadow-2xs shrink-0"
                  >
                    <Upload className="w-4 h-4 text-[#1B3A5C]" />
                    <span>{isProcessingImage ? 'Compressing photo...' : 'Choose Photo from Device'}</span>
                  </button>

                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#1B3A5C]/60">
                      <ImageIcon className="w-4 h-4" />
                    </div>
                    <input
                      type="url"
                      value={customImage}
                      onChange={(e) => {
                        setCustomImage(e.target.value);
                        if (e.target.value) {
                          setImageBase64('');
                          setImageFileName('');
                        }
                      }}
                      placeholder="Or paste image URL link..."
                      className="w-full pl-9 pr-3 py-3 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-xs font-bold text-[#1B3A5C] focus:outline-none focus:border-[#E63946]"
                    />
                  </div>
                </div>

                {/* Photo Preview & Status */}
                <div className="p-3 bg-[#FAFBFC] border-2 border-dashed border-[#1B3A5C]/30 rounded-2xl flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {isProcessingImage ? (
                      <div className="w-12 h-12 rounded-xl bg-[#FFD93D] border-2 border-[#1B3A5C] flex items-center justify-center animate-pulse">
                        <Send className="w-5 h-5 text-[#E63946] animate-bounce" />
                      </div>
                    ) : (
                      <img
                        src={imageBase64 || customImage || CATEGORY_PRESET_IMAGES[category]}
                        alt="Preview"
                        className="w-12 h-12 rounded-xl object-cover border-2 border-[#1B3A5C] shadow-2xs shrink-0"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = CATEGORY_PRESET_IMAGES[category];
                        }}
                      />
                    )}
                    <div>
                      <p className="text-xs font-black text-[#1B3A5C]">
                        {isProcessingImage
                          ? 'Compressing photo for instant loading...'
                          : imageFileName
                          ? `Uploaded: ${imageFileName}`
                          : customImage
                          ? 'Custom Image Link'
                          : `Default ${category} Preset Photo`}
                      </p>
                      <p className="text-[11px] text-[#1B3A5C]/70 font-bold">
                        {imageBase64
                          ? 'Optimized base64 photo ready'
                          : 'Compact photo stored safely on Firestore'}
                      </p>
                    </div>
                  </div>

                  {imageBase64 && (
                    <button
                      type="button"
                      onClick={() => {
                        setImageBase64('');
                        setImageFileName('');
                      }}
                      className="text-xs font-bold text-[#E63946] hover:underline cursor-pointer"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            </div>

            {/* Seller Contact Info (Pre-filled for rapid posting) */}
            <div className="pt-4 border-t-2 border-[#C9E2F5] grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-black text-[#1B3A5C] mb-1 flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-[#1B3A5C]" /> Seller Name
                </label>
                <input
                  type="text"
                  value={sellerName}
                  onChange={(e) => setSellerName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-xs text-[#1B3A5C] font-bold"
                />
              </div>
              <div>
                <label className="block text-xs font-black text-[#1B3A5C] mb-1 flex items-center gap-1">
                  <Building className="w-3.5 h-3.5 text-[#1B3A5C]" /> Hostel & Room
                </label>
                <input
                  type="text"
                  value={sellerHostel}
                  onChange={(e) => setSellerHostel(e.target.value)}
                  className="w-full px-3 py-2 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-xs text-[#1B3A5C] font-bold"
                />
              </div>
            </div>

            {/* Submit Button: Red Pill-Shaped */}
            <button
              type="submit"
              disabled={isSubmitting}
              id="submit-listing-btn"
              className="w-full py-4 px-6 bg-[#E63946] hover:bg-[#D62839] text-white font-black text-base rounded-full shadow-md hover:-translate-y-0.5 transition-all active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer border-2 border-[#1B3A5C]"
            >
              <Tag className="w-5 h-5 text-white" />
              <span>Post Listing Immediately</span>
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
