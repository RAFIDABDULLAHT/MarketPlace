import React, { useState } from 'react';
import { Listing } from '../types';
import { X, MessageSquare, Phone, MapPin, Send, CheckCircle2, Copy, ExternalLink } from 'lucide-react';

interface SellerModalProps {
  listing: Listing | null;
  onClose: () => void;
}

export const SellerModal: React.FC<SellerModalProps> = ({ listing, onClose }) => {
  if (!listing) return null;

  const [message, setMessage] = useState(
    `Hi ${listing.sellerName}, I saw your listing for "${listing.title}" (₹${listing.price}) on Campus Market. Is it available for hostel pickup?`
  );
  const [copied, setCopied] = useState(false);
  const [sentMessage, setSentMessage] = useState(false);

  const handleCopyText = () => {
    navigator.clipboard.writeText(message);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSimulatedSend = (e: React.FormEvent) => {
    e.preventDefault();
    setSentMessage(true);
  };

  const sanitizePhone = listing.sellerPhone.replace(/\D/g, '');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1B3A5C]/60 backdrop-blur-xs animate-fade-in">
      <div className="bg-[#FAFBFC] rounded-2xl border-2 border-[#1B3A5C] max-w-lg w-full p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-[#1B3A5C] hover:bg-[#C9E2F5]/50 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-5 border-b-2 border-[#C9E2F5] pb-4">
          <div className="w-10 h-10 rounded-full bg-[#FFD93D] border-2 border-[#1B3A5C] text-[#1B3A5C] flex items-center justify-center font-black text-base shrink-0">
            {listing.sellerName.charAt(0)}
          </div>
          <div>
            <h3 className="text-lg font-black text-[#1B3A5C] leading-snug">
              Contact {listing.sellerName}
            </h3>
            <p className="text-xs text-[#1B3A5C] font-bold flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-[#E63946]" />
              {listing.sellerHostel}
            </p>
          </div>
        </div>

        {/* Item Summary Banner */}
        <div className="bg-[#FAFBFC] p-3.5 rounded-2xl border-2 border-[#1B3A5C]/20 flex items-center gap-3 mb-6">
          <img
            src={listing.imageUrl}
            alt={listing.title}
            className="w-12 h-12 rounded-xl object-cover shrink-0 border-2 border-[#1B3A5C]"
          />
          <div className="flex-1 min-w-0">
            <h4 className="text-xs font-black text-[#1B3A5C] truncate">{listing.title}</h4>
            <div className="flex items-center gap-2 mt-0.5">
              <span className="text-xs font-black text-[#E63946] bg-[#FFD93D] px-2 py-0.5 rounded-full border border-[#1B3A5C]">
                ₹{listing.price}
              </span>
              <span className="text-[11px] text-[#1B3A5C] font-bold">{listing.condition}</span>
            </div>
          </div>
        </div>

        {sentMessage ? (
          <div className="py-8 text-center">
            <div className="w-12 h-12 rounded-full bg-emerald-100 border-2 border-emerald-600 text-emerald-800 flex items-center justify-center mx-auto mb-3 animate-bounce">
              <CheckCircle2 className="w-7 h-7" />
            </div>
            <h4 className="text-base font-black text-[#1B3A5C] mb-1">Message Sent to {listing.sellerName}!</h4>
            <p className="text-xs text-[#1B3A5C] font-bold max-w-xs mx-auto mb-6">
              The seller will receive your hostel chat notification and reply shortly. You can also call directly.
            </p>
            <button
              onClick={onClose}
              className="w-full py-3 bg-[#E63946] text-white font-black text-xs rounded-full hover:bg-[#D62839] cursor-pointer border border-[#1B3A5C]"
            >
              Done
            </button>
          </div>
        ) : (
          <form onSubmit={handleSimulatedSend} className="space-y-4">
            <div>
              <label className="block text-xs font-black text-[#1B3A5C] mb-1.5 flex items-center justify-between">
                <span>Instant Message Preview:</span>
                <button
                  type="button"
                  onClick={handleCopyText}
                  className="text-[11px] text-[#E63946] hover:underline flex items-center gap-1 font-bold cursor-pointer"
                >
                  <Copy className="w-3 h-3" />
                  {copied ? 'Copied!' : 'Copy text'}
                </button>
              </label>
              <textarea
                rows={3}
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="w-full p-3 bg-[#FAFBFC] border-2 border-[#1B3A5C]/30 rounded-2xl text-xs font-bold text-[#1B3A5C] focus:outline-none focus:border-[#E63946]"
              />
            </div>

            {/* Quick Actions */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <a
                href={`https://wa.me/${sanitizePhone}?text=${encodeURIComponent(message)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="py-3 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-full border border-[#1B3A5C] flex items-center justify-center gap-1.5 text-center transition-colors"
              >
                <MessageSquare className="w-4 h-4" />
                <span>WhatsApp Seller</span>
                <ExternalLink className="w-3 h-3 opacity-70" />
              </a>

              <a
                href={`tel:${listing.sellerPhone}`}
                className="py-3 px-3 bg-[#FFD93D] hover:bg-amber-300 text-[#1B3A5C] font-black text-xs rounded-full border-2 border-[#1B3A5C] flex items-center justify-center gap-1.5 text-center transition-colors"
              >
                <Phone className="w-4 h-4 text-[#1B3A5C]" />
                <span>Call {listing.sellerPhone}</span>
              </a>
            </div>

            <button
              type="submit"
              className="w-full mt-2 py-3 bg-[#E63946] hover:bg-[#D62839] text-white font-black text-xs rounded-full shadow-2xs flex items-center justify-center gap-2 transition-all cursor-pointer border border-[#1B3A5C]"
            >
              <Send className="w-3.5 h-3.5 text-white" />
              <span>Send In-App Campus Ping</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
