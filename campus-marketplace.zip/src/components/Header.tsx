import React from 'react';
import { Pencil, PlusCircle, Compass, ShoppingCart } from 'lucide-react';

interface HeaderProps {
  onSellClick: () => void;
  onBrowseClick: () => void;
  totalListingsCount: number;
}

export const Header: React.FC<HeaderProps> = ({ onSellClick, onBrowseClick, totalListingsCount }) => {
  return (
    <header className="sticky top-0 z-40 bg-[#FAFBFC] backdrop-blur-md border-b-2 border-[#C9E2F5] shadow-xs transition-all">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-4">
        {/* Campus Pencil Doodle Logo & Brand */}
        <div 
          onClick={onBrowseClick}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-2xl bg-[#FFD93D] border-2 border-[#1B3A5C] text-[#1B3A5C] flex items-center justify-center shadow-2xs group-hover:rotate-6 transition-transform">
            <Pencil className="w-5 h-5 text-[#1B3A5C]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-[#1B3A5C] text-lg tracking-tight group-hover:text-[#E63946] transition-colors">
                CampusMarket
              </span>
              <span className="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 bg-[#FFD93D] text-[#1B3A5C] rounded-full border border-[#1B3A5C]">
                VIT
              </span>
            </div>
            <p className="text-[11px] text-[#1B3A5C]/70 font-bold hidden sm:block">Student Notebook Exchange</p>
          </div>
        </div>

        {/* Right CTA Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={onBrowseClick}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#1B3A5C] hover:text-[#E63946] px-3 py-2 rounded-2xl hover:bg-[#C9E2F5]/40 transition-colors"
          >
            <Compass className="w-4 h-4 text-[#1B3A5C]" />
            <span className="hidden sm:inline">Explore ({totalListingsCount})</span>
            <span className="sm:hidden">Browse</span>
          </button>

          <button
            onClick={onBrowseClick}
            aria-label="View Active Cart Items"
            className="relative p-2.5 rounded-full text-[#1B3A5C] bg-[#FAFBFC] hover:bg-[#C9E2F5]/50 border-2 border-[#1B3A5C] transition-colors"
          >
            <ShoppingCart className="w-4 h-4 text-[#1B3A5C]" />
            {totalListingsCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#E63946] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {totalListingsCount}
              </span>
            )}
          </button>

          <button
            onClick={onSellClick}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-bold text-white bg-[#E63946] hover:bg-[#D62839] px-5 py-2.5 rounded-full shadow-md hover:-translate-y-0.5 transition-all active:scale-95 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-white" />
            <span>Sell Item</span>
          </button>
        </div>
      </div>
    </header>
  );
};
