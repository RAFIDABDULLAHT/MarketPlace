import React, { useState } from 'react';
import { Listing, Category } from '../types';
import { MessageSquare, IndianRupee, MapPin, Sparkles, Heart, Send, Check, BookOpen, Bike, Laptop, Package } from 'lucide-react';
import { CATEGORY_PRESET_IMAGES } from '../data/mockListings';
import { motion } from 'motion/react';

interface ListingCardProps {
  listing: Listing;
  onMessageSeller: (listing: Listing) => void;
  isFavourite: boolean;
  onToggleFavourite: (id: string) => void;
}

export const ListingCard: React.FC<ListingCardProps> = ({
  listing,
  onMessageSeller,
  isFavourite,
  onToggleFavourite,
}) => {
  const [imageError, setImageError] = useState(false);
  const [showCopiedToast, setShowCopiedToast] = useState(false);

  // Native share or clipboard fallback
  const handleShare = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const shareLink = `${window.location.origin}${window.location.pathname}?item=${listing.id}`;
    const formattedPrice = listing.price.toLocaleString('en-IN');
    const messageText = `${listing.title} — ₹${formattedPrice}, ${listing.condition}. Check it out on Campus Cart: ${shareLink}`;

    if (navigator.share) {
      try {
        await navigator.share({
          title: `${listing.title} on Campus Cart`,
          text: `${listing.title} — ₹${formattedPrice}, ${listing.condition}. Check it out on Campus Cart:`,
          url: shareLink,
        });
        return;
      } catch (err) {
        // User cancelled share or non-fatal abort
      }
    }

    try {
      await navigator.clipboard.writeText(messageText);
      setShowCopiedToast(true);
      setTimeout(() => {
        setShowCopiedToast(false);
      }, 2500);
    } catch (err) {
      console.error('Failed to copy share link to clipboard:', err);
    }
  };

  // Determine slight index card rotation based on listing ID
  const isRotateLeft = listing.id.charCodeAt(listing.id.length - 1) % 2 === 0;
  const rotationClass = isRotateLeft ? 'pinned-card-left' : 'pinned-card-right';

  // Category placeholder icon helper
  const renderCategoryIcon = (category: Category) => {
    switch (category) {
      case 'Books':
        return <BookOpen className="w-12 h-12 text-[#1B3A5C]" />;
      case 'Cycles':
        return <Bike className="w-12 h-12 text-[#1B3A5C]" />;
      case 'Electronics':
        return <Laptop className="w-12 h-12 text-[#1B3A5C]" />;
      default:
        return <Package className="w-12 h-12 text-[#1B3A5C]" />;
    }
  };

  const hasImage = Boolean(listing.imageUrl || listing.imageBase64) && !imageError;
  const imageSource = listing.imageBase64 || listing.imageUrl;

  return (
    <motion.div
      initial={{ opacity: 0, y: 24, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.45, ease: 'easeOut' }}
      className={`bg-[#FAFBFC] rounded-2xl border-2 border-[#1B3A5C]/20 shadow-sm hover:shadow-md transition-all duration-300 flex flex-col overflow-hidden relative group ${rotationClass} ${
        listing.isNew ? 'new-item-highlight ring-4 ring-[#E63946]' : ''
      }`}
    >
      {/* Paper-plane uploading... state banner overlay if processing/uploading */}
      {listing.isUploading && (
        <div className="absolute inset-0 z-30 bg-[#1B3A5C]/80 backdrop-blur-xs flex flex-col items-center justify-center text-white p-4 text-center animate-fade-in">
          <div className="w-12 h-12 rounded-full bg-[#FFD93D] border-2 border-[#1B3A5C] flex items-center justify-center mb-2 shadow-md">
            <Send className="w-6 h-6 text-[#E63946] animate-bounce" />
          </div>
          <p className="text-xs font-black uppercase tracking-wider text-[#FFD93D] mb-0.5">Paper-Plane Sync</p>
          <p className="text-sm font-extrabold text-white">uploading…</p>
        </div>
      )}

      {/* New Listing Badge */}
      {listing.isNew && (
        <div className="absolute top-3 left-3 z-10 bg-[#E63946] text-white text-[11px] font-black uppercase tracking-wider px-3 py-1 rounded-full shadow-md flex items-center gap-1 border border-[#1B3A5C] animate-pulse">
          <Sparkles className="w-3.5 h-3.5 text-white" /> NEW
        </div>
      )}

      {/* Image Container with Sticky Yellow Category Tag & Condition Badge */}
      <div className="relative aspect-4/3 w-full bg-[#C9E2F5]/30 overflow-hidden border-b-2 border-[#1B3A5C]/15 flex items-center justify-center">
        {hasImage ? (
          <img
            src={imageSource}
            alt={listing.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            onError={() => setImageError(true)}
          />
        ) : (
          /* Placeholder icon matching category if listing has no image yet */
          <div className="w-full h-full bg-[#FFD93D]/20 border-2 border-dashed border-[#1B3A5C]/30 flex flex-col items-center justify-center gap-2 p-4 text-center">
            <div className="p-3 bg-[#FFD93D] rounded-2xl border-2 border-[#1B3A5C] shadow-2xs">
              {renderCategoryIcon(listing.category)}
            </div>
            <span className="text-xs font-black text-[#1B3A5C]">{listing.category} Item</span>
          </div>
        )}

        {/* Hand-Drawn Doodle Style Heart/Favourite Icon in Top-Right Corner */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleFavourite(listing.id);
          }}
          aria-label={isFavourite ? 'Remove from favourites' : 'Add to favourites'}
          className="absolute top-3 right-3 z-20 w-9 h-9 rounded-full bg-[#FAFBFC] border-2 border-[#1B3A5C] flex items-center justify-center shadow-md hover:scale-110 active:scale-95 transition-transform cursor-pointer"
        >
          <Heart
            className={`w-5 h-5 stroke-[2.5] transition-colors ${
              isFavourite
                ? 'fill-[#E63946] text-[#E63946]'
                : 'fill-transparent text-[#1B3A5C] hover:text-[#E63946]'
            }`}
          />
        </button>
        
        {/* Top Condition Badge */}
        <div className={`absolute ${listing.isNew ? 'top-12 left-3' : 'top-3 left-3'} flex flex-col items-start gap-1.5 z-10`}>
          <span className="text-[11px] font-extrabold px-3 py-1 rounded-full bg-[#FAFBFC] text-[#1B3A5C] border-2 border-[#1B3A5C] shadow-2xs">
            {listing.condition}
          </span>
        </div>

        {/* Bottom Corner Sticky-Note Yellow Category Tag */}
        <div className="absolute bottom-3 left-3 z-10">
          <span className="text-[11px] font-black px-3 py-1 rounded-full bg-[#FFD93D] text-[#1B3A5C] border-2 border-[#1B3A5C] shadow-xs">
            {listing.category}
          </span>
        </div>
      </div>

      {/* Card Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          {/* Title & Price Tag in Notebook-Red */}
          <div className="flex items-start justify-between gap-2 mb-2">
            <h3 className="text-base font-extrabold text-[#1B3A5C] tracking-tight leading-snug line-clamp-2 group-hover:text-[#E63946] transition-colors">
              {listing.title}
            </h3>
            <div className="text-right shrink-0">
              <span className="inline-flex items-center text-xl font-black text-[#E63946] bg-[#FAFBFC] px-2.5 py-0.5 rounded-xl border-2 border-[#E63946]/30">
                <IndianRupee className="w-4 h-4 mr-0.5 text-[#E63946]" />
                {listing.price.toLocaleString('en-IN')}
              </span>
            </div>
          </div>

          {/* Short Description */}
          <p className="text-xs text-[#1B3A5C] font-semibold line-clamp-3 leading-relaxed mb-4">
            {listing.description}
          </p>
        </div>

        {/* Footer Meta & Seller Action */}
        <div className="pt-3 border-t-2 border-[#C9E2F5] mt-2">
          {/* Seller Hostel Tag */}
          <div className="flex items-center justify-between text-xs text-[#1B3A5C] font-bold mb-3">
            <span className="truncate max-w-[140px]">
              {listing.sellerName}
            </span>
            <span className="flex items-center gap-1 text-[11px] bg-[#FFD93D]/60 text-[#1B3A5C] px-2.5 py-0.5 rounded-full border border-[#1B3A5C]/40 truncate max-w-[140px]">
              <MapPin className="w-3 h-3 text-[#E63946] shrink-0" />
              {listing.sellerHostel}
            </span>
          </div>

          {/* Action Buttons: Message Seller & Share */}
          <div className="flex items-center gap-2 relative">
            <button
              onClick={() => onMessageSeller(listing)}
              className="flex-1 py-2.5 px-3 bg-[#E63946] hover:bg-[#D62839] text-white font-extrabold text-xs sm:text-sm rounded-full transition-all shadow-xs hover:-translate-y-0.5 flex items-center justify-center gap-1.5 active:scale-[0.98] cursor-pointer border border-[#1B3A5C]"
            >
              <MessageSquare className="w-4 h-4 text-white" />
              <span>Message seller</span>
            </button>

            <button
              onClick={handleShare}
              title="Share listing"
              aria-label="Share listing"
              className="py-2.5 px-3.5 bg-[#FFD93D] hover:bg-amber-300 text-[#1B3A5C] font-black text-xs rounded-full transition-all shadow-xs hover:-translate-y-0.5 flex items-center justify-center gap-1.5 active:scale-[0.98] cursor-pointer border border-[#1B3A5C] shrink-0"
            >
              {showCopiedToast ? (
                <>
                  <Check className="w-4 h-4 text-emerald-800" />
                  <span className="text-xs font-black text-emerald-900">Copied!</span>
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 text-[#1B3A5C]" />
                  <span className="hidden sm:inline">Share</span>
                </>
              )}
            </button>

            {/* Desktop Copied Floating Banner */}
            {showCopiedToast && (
              <div className="absolute -top-10 right-0 z-30 bg-[#1B3A5C] text-[#FFD93D] text-[11px] font-black px-3 py-1.5 rounded-xl border border-[#FFD93D] shadow-lg flex items-center gap-1.5 animate-bounce">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Copied to clipboard!</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </motion.div>
  );
};
