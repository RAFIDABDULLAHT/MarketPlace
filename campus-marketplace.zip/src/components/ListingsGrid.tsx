import React, { useState, useEffect } from 'react';
import { Category, Listing } from '../types';
import { ListingCard } from './ListingCard';
import { ListingsCounter } from './ListingsCounter';
import { Search, Heart, AlertCircle } from 'lucide-react';

interface ListingsGridProps {
  listings: Listing[];
  onMessageSeller: (listing: Listing) => void;
}

export const ListingsGrid: React.FC<ListingsGridProps> = ({ listings, onMessageSeller }) => {
  const [selectedCategory, setSelectedCategory] = useState<Category | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'favourites'>('all');

  // Load favourites from localStorage
  const [favourites, setFavourites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('campus_favourites');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Persist favourites to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('campus_favourites', JSON.stringify(favourites));
    } catch (e) {
      console.error(e);
    }
  }, [favourites]);

  const toggleFavourite = (id: string) => {
    setFavourites((prev) =>
      prev.includes(id) ? prev.filter((favId) => favId !== id) : [...prev, id]
    );
  };

  const categories: (Category | 'All')[] = ['All', 'Books', 'Cycles', 'Electronics', 'Other'];

  // Filter listings based on active tab, category, and search query (by item name)
  const filteredListings = listings.filter((item) => {
    const matchesTab = activeTab === 'all' || favourites.includes(item.id);
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesTab && matchesCategory && matchesSearch;
  });

  return (
    <section id="listings-grid" className="py-12 md:py-16 graph-paper-bg min-h-[600px] border-t-2 border-[#C9E2F5]">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        {/* Top Header Row with Tabs and Animated Counter */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-black uppercase tracking-widest text-[#1B3A5C] bg-[#FFD93D] px-3 py-1 rounded-full border border-[#1B3A5C]">
                Verified Campus Exchange
              </span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-[#1B3A5C] tracking-tight mb-3">
              Live Campus Listings
            </h2>

            {/* "All listings" and "My favourites" Tabs */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-5 py-2 rounded-full text-xs sm:text-sm font-black transition-all cursor-pointer border-2 flex items-center gap-2 ${
                  activeTab === 'all'
                    ? 'bg-[#1B3A5C] border-[#1B3A5C] text-white shadow-xs'
                    : 'bg-[#FAFBFC] border-[#1B3A5C] text-[#1B3A5C] hover:bg-[#C9E2F5]/40'
                }`}
              >
                <span>All listings</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${activeTab === 'all' ? 'bg-white/20 text-white' : 'bg-[#C9E2F5]/50 text-[#1B3A5C]'}`}>
                  {listings.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('favourites')}
                className={`px-5 py-2 rounded-full text-xs sm:text-sm font-black transition-all cursor-pointer border-2 flex items-center gap-2 ${
                  activeTab === 'favourites'
                    ? 'bg-[#E63946] border-[#E63946] text-white shadow-xs'
                    : 'bg-[#FAFBFC] border-[#1B3A5C] text-[#1B3A5C] hover:bg-[#C9E2F5]/40'
                }`}
              >
                <Heart className={`w-4 h-4 ${favourites.length > 0 ? 'fill-[#E63946] text-[#E63946]' : ''}`} />
                <span>My favourites</span>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${activeTab === 'favourites' ? 'bg-white/20 text-white' : 'bg-[#FFD93D] text-[#1B3A5C] border border-[#1B3A5C]'}`}>
                  {favourites.length}
                </span>
              </button>
            </div>
          </div>

          {/* Above grid counter */}
          <div className="self-start md:self-auto">
            <ListingsCounter targetCount={filteredListings.length} />
          </div>
        </div>

        {/* Search & Category Filter Section */}
        <div className="space-y-4 mb-8">
          {/* (1) Search Bar: Paper-white pill shape matching theme */}
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-[#1B3A5C]">
              <Search className="w-5 h-5 text-[#1B3A5C]" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search for books, cycles, electronics…"
              className="w-full pl-12 pr-5 py-3.5 bg-[#FAFBFC] border-2 border-[#1B3A5C] rounded-full text-sm font-bold text-[#1B3A5C] placeholder:text-[#1B3A5C]/50 focus:outline-none focus:border-[#E63946] focus:ring-2 focus:ring-[#E63946]/20 shadow-xs transition-all"
            />
          </div>

          {/* (2) Category Filter Chips: Directly below search bar */}
          <div className="flex items-center gap-2.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-5 py-2 rounded-full text-xs sm:text-sm font-black whitespace-nowrap transition-all cursor-pointer border-2 ${
                  selectedCategory === cat
                    ? 'bg-[#E63946] border-[#E63946] text-white shadow-2xs scale-105'
                    : 'bg-[#FAFBFC] border-[#1B3A5C] text-[#1B3A5C] hover:bg-[#C9E2F5]/40'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Grid or Empty State */}
        {filteredListings.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {filteredListings.map((item) => (
              <ListingCard
                key={item.id}
                listing={item}
                onMessageSeller={onMessageSeller}
                isFavourite={favourites.includes(item.id)}
                onToggleFavourite={toggleFavourite}
              />
            ))}
          </div>
        ) : (
          <div className="bg-[#FAFBFC] rounded-2xl border-2 border-dashed border-[#1B3A5C]/40 p-12 text-center max-w-md mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-[#FFD93D] text-[#1B3A5C] border-2 border-[#1B3A5C] flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-[#1B3A5C] mb-1">No listings found</h3>
            <p className="text-xs text-[#1B3A5C] font-bold mb-6">
              {activeTab === 'favourites'
                ? "You haven't favourited any items yet. Click the heart icon on any card to save it here!"
                : "No items match your selected filter or search keyword. Try clearing filters or searching for something else!"}
            </p>
            <button
              onClick={() => {
                setSelectedCategory('All');
                setSearchQuery('');
                setActiveTab('all');
              }}
              className="text-xs font-black text-white bg-[#E63946] hover:bg-[#D62839] px-5 py-2.5 rounded-full transition-colors border border-[#1B3A5C] cursor-pointer"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
