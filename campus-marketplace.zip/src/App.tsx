import React, { useState, useEffect } from 'react';
import { Listing } from './types';
import { INITIAL_LISTINGS } from './data/mockListings';
import { subscribeToListings, seedInitialListingsIfEmpty } from './lib/firebase';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { SellForm } from './components/SellForm';
import { ListingsGrid } from './components/ListingsGrid';
import { Footer } from './components/Footer';
import { SellerModal } from './components/SellerModal';

export default function App() {
  const [listings, setListings] = useState<Listing[]>([]);
  const [activeSellerModal, setActiveSellerModal] = useState<Listing | null>(null);

  // Seed initial listings if empty and subscribe to real-time Firestore updates
  useEffect(() => {
    let unsubscribe: () => void = () => {};

    const initFirebase = async () => {
      await seedInitialListingsIfEmpty();
      unsubscribe = subscribeToListings((items) => {
        if (items.length > 0) {
          setListings(items);
        } else {
          setListings(INITIAL_LISTINGS);
        }
      });
    };

    initFirebase();

    return () => {
      unsubscribe();
    };
  }, []);

  // Smooth scroll handler to listings grid
  const scrollToGrid = () => {
    const gridEl = document.getElementById('listings-grid');
    if (gridEl) {
      gridEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Smooth scroll handler to sell form
  const scrollToSellForm = () => {
    const formEl = document.getElementById('sell-form-section');
    if (formEl) {
      formEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen graph-paper-bg text-[#1B3A5C] font-sans selection:bg-[#FFD93D] selection:text-[#1B3A5C] flex flex-col antialiased">
      {/* Navigation Header */}
      <Header
        onSellClick={scrollToSellForm}
        onBrowseClick={scrollToGrid}
        totalListingsCount={listings.length}
      />

      {/* Main Content Area in Order: (1) Hero, (2) Sell Form, (3) Listings Grid */}
      <main className="flex-1">
        {/* Section 1: Hero Section */}
        <HeroSection
          onBrowseClick={scrollToGrid}
          onSellClick={scrollToSellForm}
        />

        {/* Section 2: Sell an Item Form */}
        <SellForm />

        {/* Section 3: Live Listings Grid with Counter */}
        <ListingsGrid
          listings={listings}
          onMessageSeller={(item) => setActiveSellerModal(item)}
        />
      </main>

      {/* Section 4: Footer */}
      <Footer />

      {/* Seller Message Modal */}
      <SellerModal
        listing={activeSellerModal}
        onClose={() => setActiveSellerModal(null)}
      />
    </div>
  );
}
