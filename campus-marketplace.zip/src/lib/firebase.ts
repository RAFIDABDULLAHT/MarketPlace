import { initializeApp, getApps } from 'firebase/app';
import {
  getFirestore,
  collection,
  query,
  orderBy,
  onSnapshot,
  addDoc,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfigData from '../../firebase-applet-config.json';
import { Listing, Category, Condition } from '../types';
import { INITIAL_LISTINGS } from '../data/mockListings';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || firebaseConfigData.apiKey || "AIzaSyDTZ2hovkZs_vkxJXZlnAr6Euv9Sosy6KI",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || firebaseConfigData.authDomain || "marketplace-c6226.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || firebaseConfigData.projectId || "marketplace-c6226",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || firebaseConfigData.storageBucket || "marketplace-c6226.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || firebaseConfigData.messagingSenderId || "257671278705",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || firebaseConfigData.appId || "1:257671278705:web:312e0ad6b7b88b4e48abd0",
};

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

// Initialize Firestore with databaseId if specified
export const db = getFirestore(app, firebaseConfigData.firestoreDatabaseId || undefined);

export interface FirestoreListingDoc {
  name: string;
  category: string;
  price: number;
  condition: string;
  description: string;
  imageBase64: string;
  createdAt: string;
  sellerId: string;
  sellerName?: string;
  sellerHostel?: string;
  sellerPhone?: string;
}

// Client persistent seller ID
export const getOrGenerateSellerId = (): string => {
  try {
    let id = localStorage.getItem('campus_seller_id');
    if (!id) {
      id = 'seller_' + Math.random().toString(36).substring(2, 10);
      localStorage.setItem('campus_seller_id', id);
    }
    return id;
  } catch {
    return 'seller_' + Math.random().toString(36).substring(2, 10);
  }
};

// Image compression helper: converts File or Canvas to compressed JPEG base64 string
export const compressImageFileToBase64 = (
  file: File,
  maxWidth = 600,
  maxHeight = 600,
  quality = 0.7
): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(event.target?.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedBase64 = canvas.toDataURL('image/jpeg', quality);
        resolve(compressedBase64);
      };
      img.onerror = (err) => reject(err);
    };
    reader.onerror = (err) => reject(err);
  });
};

// Convert image URL to compressed Base64
export const urlToBase64 = async (url: string): Promise<string> => {
  try {
    const response = await fetch(url);
    const blob = await response.blob();
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result as string);
      reader.onerror = () => resolve('');
      reader.readAsDataURL(blob);
    });
  } catch {
    return '';
  }
};

// Seed initial listings if collection is empty
export const seedInitialListingsIfEmpty = async () => {
  try {
    const listingsRef = collection(db, 'listings');
    const snapshot = await getDocs(listingsRef);
    if (snapshot.empty) {
      const sellerId = getOrGenerateSellerId();
      for (const item of INITIAL_LISTINGS) {
        await addDoc(listingsRef, {
          name: item.title,
          category: item.category,
          price: item.price,
          condition: item.condition,
          description: item.description,
          imageBase64: item.imageUrl,
          createdAt: new Date().toISOString(),
          sellerId: sellerId,
          sellerName: item.sellerName,
          sellerHostel: item.sellerHostel,
          sellerPhone: item.sellerPhone,
        });
      }
    }
  } catch (error) {
    console.error('Error seeding initial listings:', error);
  }
};

// Add listing to Firestore
export const createListingInFirestore = async (data: {
  name: string;
  category: Category;
  price: number;
  condition: Condition;
  description: string;
  imageBase64: string;
  sellerName: string;
  sellerHostel: string;
  sellerPhone: string;
}) => {
  const sellerId = getOrGenerateSellerId();
  const listingsRef = collection(db, 'listings');
  const docRef = await addDoc(listingsRef, {
    name: data.name,
    category: data.category,
    price: data.price,
    condition: data.condition,
    description: data.description,
    imageBase64: data.imageBase64,
    createdAt: new Date().toISOString(),
    sellerId: sellerId,
    sellerName: data.sellerName,
    sellerHostel: data.sellerHostel,
    sellerPhone: data.sellerPhone,
  });
  return docRef.id;
};

// Real-time listener for listings collection ordered by createdAt descending
export const subscribeToListings = (
  callback: (listings: Listing[]) => void,
  onError?: (error: Error) => void
) => {
  const listingsRef = collection(db, 'listings');
  const q = query(listingsRef, orderBy('createdAt', 'desc'));

  return onSnapshot(
    q,
    (snapshot) => {
      const items: Listing[] = snapshot.docs.map((doc) => {
        const data = doc.data() as FirestoreListingDoc;
        return {
          id: doc.id,
          title: data.name || 'Untitled Item',
          category: (data.category as Category) || 'Other',
          price: data.price || 0,
          condition: (data.condition as Condition) || 'Good',
          description: data.description || '',
          imageUrl: data.imageBase64 || '',
          imageBase64: data.imageBase64 || '',
          sellerId: data.sellerId || '',
          sellerName: data.sellerName || 'Campus Student',
          sellerHostel: data.sellerHostel || 'MH Hostel',
          sellerPhone: data.sellerPhone || '+91 98765 43210',
          createdAt: data.createdAt || new Date().toISOString(),
        };
      });
      callback(items);
    },
    (err) => {
      console.warn('Firestore subscription fallback triggered:', err);
      // Fallback to initial mock listings so UI remains fully interactive
      callback(INITIAL_LISTINGS);
      if (onError) onError(err);
    }
  );
};
