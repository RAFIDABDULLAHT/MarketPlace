import { Listing } from '../types';

export const CATEGORY_PRESET_IMAGES: Record<string, string> = {
  Books: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800',
  Cycles: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=800',
  Electronics: 'https://images.unsplash.com/photo-1611125832047-1d7ad1e8e48a?auto=format&fit=crop&q=80&w=800',
  Other: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?auto=format&fit=crop&q=80&w=800',
};

export const INITIAL_LISTINGS: Listing[] = [
  {
    id: 'listing-1',
    title: 'Data Structures & Algorithms in Java (4th Ed)',
    category: 'Books',
    price: 450,
    condition: 'Good',
    description: 'Slightly highlighted chapters 3 & 4. Essential textbook for CS201 & CS202. Includes printed lab practice sheets and problem set solutions!',
    imageUrl: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?auto=format&fit=crop&q=80&w=800',
    sellerName: 'Ananya Sharma',
    sellerHostel: 'MH-4 Hostel, Room 302',
    sellerPhone: '+91 98765 43210',
    createdAt: '2 hours ago',
  },
  {
    id: 'listing-2',
    title: 'Hero Octane 21-Speed Hybrid Cycle',
    category: 'Cycles',
    price: 3200,
    condition: 'Like New',
    description: 'Smooth gear shifting, dual disc brakes, rust-free alloy frame. Bought last semester for quick rides between academics block and hostel. Includes cable lock & helmet.',
    imageUrl: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=800',
    sellerName: 'Rohan Verma',
    sellerHostel: 'LH-2 Hostel, Room 114',
    sellerPhone: '+91 98123 45678',
    createdAt: '5 hours ago',
  },
  {
    id: 'listing-3',
    title: 'Casio FX-991EX ClassWiz Calculator',
    category: 'Electronics',
    price: 850,
    condition: 'Like New',
    description: 'Must-have scientific calculator for EE, ME, and CS engineering maths exams. High-res display, QR code output support. Brand new battery fitted last week.',
    imageUrl: 'https://images.unsplash.com/photo-1611125832047-1d7ad1e8e48a?auto=format&fit=crop&q=80&w=800',
    sellerName: 'Vikram Patel',
    sellerHostel: 'MH-1 Hostel, Room 408',
    sellerPhone: '+91 97654 32109',
    createdAt: '1 day ago',
  },
];
