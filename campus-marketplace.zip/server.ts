import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for AI Item Description Polish
  app.post('/api/generate-description', async (req, res) => {
    try {
      const { title, category, condition } = req.body;
      if (!title) {
        return res.status(400).json({ error: 'Title is required' });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (apiKey) {
        const ai = new GoogleGenAI({ apiKey });
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are an energetic college student posting a used item for sale on the campus marketplace.
Item Name: ${title}
Category: ${category}
Condition: ${condition}

Write a short, engaging, 2-sentence description highlighting key benefits for campus students (e.g., course usefulness, hostel convenience, condition details). Do NOT use quotation marks.`,
        });

        const text = response.text?.trim();
        if (text) {
          return res.json({ description: text });
        }
      }

      // Fallback description generator
      const defaultDesc = `Clean, well-maintained ${title} in ${condition.toLowerCase()} condition. Perfect for hostel students and semester coursework. Pickup available at campus quad!`;
      return res.json({ description: defaultDesc });
    } catch (err) {
      console.error('Error generating description:', err);
      return res.json({
        description: `Great deal on this ${req.body.title || 'item'} in ${req.body.condition || 'good'} condition! Ready for quick hostel pickup.`,
      });
    }
  });

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Vite middleware for development vs static serve for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
